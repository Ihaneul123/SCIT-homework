package com.example.demo.controller;

import com.example.demo.service.MemberService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import com.example.demo.dto.MemberDTO;

@Slf4j
@RequiredArgsConstructor
@Controller
public class MemberController {

    private final MemberService memberService;

    /**로그인페이지로 이동**/
    @GetMapping("/member/login")
    public String loginForm() {
        return "member/login";
    }

    /**회원가입페이지로 이동**/
    @GetMapping("/member/join")
    public String joinForm() {
        return "member/join";
    }

    /**가입폼으로 이동
     * 회원가입후 메인페이지로 리다이렉트**/
    @PostMapping("/member/join")
    public String join(@ModelAttribute MemberDTO member){
        log.debug("가입정보:", member);
        memberService.join(member);
        return "redirect:/";
    }

}
