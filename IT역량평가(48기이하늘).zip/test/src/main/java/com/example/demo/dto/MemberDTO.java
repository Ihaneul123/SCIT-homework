package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberDTO {
    String memberId;                //회원 아이디
    String memberPw;          //비밀번호
    String name;              //이름
    String email;                   //이메일
}
