package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "community_board")
public class BoardEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="board_num")
    private Integer boardNum;

    @Column(name="member_id", length = 20)      // ✅ FK 컬럼 길이 고정
    private String memberId;

    @Column(name="category", nullable=false, length = 50)
    private String category;

    @Column(name="title", nullable=false, length = 200)
    private String title;

    @Column(name="contents", nullable=false, length = 2000)
    private String contents;

    @Column(name="headcnt")
    private Integer headcnt;

    @Column(name="capacity")
    private Integer capacity;

    @Column(name="status", length = 100)
    private String status;

    @CreationTimestamp
    @Column(name="create_date", updatable=false)
    private LocalDateTime createDate;
}
