package com.example.demo.repository;

import com.example.demo.entity.BoardEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BoardRepository extends JpaRepository<BoardEntity, Integer> {
    List<BoardEntity> findAllByOrderByCreateDateDesc();
    List<BoardEntity> findAllByCategoryOrderByCreateDateDesc(String category);

    List<BoardEntity> findAllByMemberIdOrderByCreateDateDesc(String memberId);

    List<BoardEntity> findAllByBoardNumInOrderByCreateDateDesc(List<Integer> boardNums);
}
