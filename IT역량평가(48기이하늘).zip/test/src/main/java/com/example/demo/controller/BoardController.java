package com.example.demo.controller;

import com.example.demo.entity.BoardEntity;
import com.example.demo.entity.GroupEntity;
import com.example.demo.repository.BoardRepository;
import com.example.demo.repository.GroupRepository;
import com.example.demo.service.BoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class BoardController {
    private final BoardRepository boardRepository;
    private final GroupRepository groupRepository;

    @GetMapping("/board/list")
    public String list(@RequestParam(defaultValue = "") String category, Model model) {
        if (category == null || category.isBlank()) {
            model.addAttribute("list", boardRepository.findAllByOrderByCreateDateDesc());
        } else {
            model.addAttribute("list", boardRepository.findAllByCategoryOrderByCreateDateDesc(category));
        }
        model.addAttribute("category", category);
        return "board/list";
    }

    // 글쓰기 폼
    @GetMapping("/board/write")
    public String writeForm() {
        return "board/write";
    }

    // 글 저장
    @PostMapping("/board/write")
    public String write(@ModelAttribute BoardEntity board, Principal principal) {

        board.setMemberId(principal.getName());
        if (board.getHeadcnt() == null) board.setHeadcnt(0);
        if (board.getStatus() == null || board.getStatus().isBlank()) board.setStatus("OPEN");

        BoardEntity saved = boardRepository.save(board);

        // ✅ 작성자는 LEADER + JOINED 로 community_group에 자동 등록
        GroupEntity leader = GroupEntity.builder()
                .boardNum(saved.getBoardNum())
                .memberId(principal.getName())
                .role("LEADER")
                .status("JOINED")
                .build();
        groupRepository.save(leader);

        return "redirect:/board/list";
    }

    @GetMapping("/board/detail")
    public String detail(@RequestParam int boardNum, Model model, Principal principal) {

        BoardEntity board = boardRepository.findById(boardNum)
                .orElseThrow(() -> new IllegalArgumentException("없는 글입니다."));

        String loginId = principal.getName();
        boolean isOwner = loginId.equals(board.getMemberId());
        boolean isOpen = "OPEN".equals(board.getStatus());

        model.addAttribute("board", board);
        model.addAttribute("isOwner", isOwner);
        model.addAttribute("isOpen", isOpen);

        return "board/detail";
    }

    @GetMapping("/board/applicants")
    public String applicants(@RequestParam int boardNum,
                             Model model,
                             Principal principal) {

        BoardEntity board = boardRepository.findById(boardNum)
                .orElseThrow(() -> new IllegalArgumentException("없는 글"));

        //  작성자만 접근 가능
        if (!principal.getName().equals(board.getMemberId())) {
            return "redirect:/board/detail?boardNum=" + boardNum;
        }

        List<GroupEntity> applicants =
                groupRepository.findAllByBoardNumOrderByJoinedDateAsc(boardNum);

        model.addAttribute("board", board);
        model.addAttribute("applicants", applicants);

        // 리더 제외 인원
        model.addAttribute("joinedCount", board.getHeadcnt());

        return "board/applicants";
    }

    @PostMapping("/group/approve")
    public String approve(@RequestParam int boardNum,
                          @RequestParam String memberId,
                          Principal principal) {

        BoardEntity board = boardRepository.findById(boardNum).orElseThrow();

        // 리더(작성자)만 가능
        if (!principal.getName().equals(board.getMemberId())) {
            return "redirect:/board/detail?boardNum=" + boardNum;
        }

        GroupEntity g = groupRepository.findByBoardNumAndMemberId(boardNum, memberId).orElseThrow();

        // ✅ 이미 JOINED/REJECTED면 중복 처리 방지
        if (!"PENDING".equals(g.getStatus())) {
            return "redirect:/board/applicants?boardNum=" + boardNum;
        }

        // ✅ 정원 초과 방지: (headcnt < capacity)일 때만 승인
        int head = (board.getHeadcnt() == null) ? 0 : board.getHeadcnt();
        int cap = (board.getCapacity() == null) ? 0 : board.getCapacity();
        if (head >= cap) {
            board.setStatus("CLOSED");
            boardRepository.save(board);
            return "redirect:/board/applicants?boardNum=" + boardNum;
        }

        // 1) 신청자 상태 JOINED
        g.setStatus("JOINED");
        groupRepository.save(g);

        // 2) 현재 인원 +1
        board.setHeadcnt(head + 1);

        // 3) 다 찼으면 마감
        if (board.getHeadcnt() >= cap) board.setStatus("CLOSED");

        boardRepository.save(board);

        return "redirect:/board/applicants?boardNum=" + boardNum;
    }

    @PostMapping("/group/reject")
    public String reject(@RequestParam int boardNum,
                         @RequestParam String memberId,
                         Principal principal) {

        BoardEntity board = boardRepository.findById(boardNum).orElseThrow();

        if (!principal.getName().equals(board.getMemberId())) {
            return "redirect:/board/detail?boardNum=" + boardNum;
        }

        GroupEntity g = groupRepository.findByBoardNumAndMemberId(boardNum, memberId).orElseThrow();
        g.setStatus("REJECTED");
        groupRepository.save(g);

        return "redirect:/board/applicants?boardNum=" + boardNum;
    }

    @PostMapping("/group/apply")
    public String apply(@RequestParam int boardNum, Principal principal) {

        BoardEntity board = boardRepository.findById(boardNum).orElseThrow();

        // 1) 본인 글 신청 금지
        if (principal.getName().equals(board.getMemberId())) {
            return "redirect:/board/detail?boardNum=" + boardNum;
        }

        // 2) 마감이면 신청 금지
        if (!"OPEN".equals(board.getStatus())) {
            return "redirect:/board/detail?boardNum=" + boardNum;
        }

        // 3) 중복 신청 금지
        if (groupRepository.existsByBoardNumAndMemberId(boardNum, principal.getName())) {
            return "redirect:/board/detail?boardNum=" + boardNum;
        }

        GroupEntity g = GroupEntity.builder()
                .boardNum(boardNum)
                .memberId(principal.getName())
                .role("MEMBER")
                .status("PENDING")
                .build();
        groupRepository.save(g);

        return "redirect:/board/detail?boardNum=" + boardNum;
    }

    private final BoardService boardService;

    @PostMapping("/board/delete")
    public String delete(@RequestParam int boardNum, Principal principal) {
        boardService.deleteBoard(boardNum, principal.getName());
        return "redirect:/board/list";
    }
}
