package com.example.demo.service;

import com.example.demo.entity.BoardEntity;
import com.example.demo.repository.BoardRepository;
import com.example.demo.repository.GroupRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class BoardService {

    private final BoardRepository boardRepository;
    private final GroupRepository groupRepository;

    @Transactional
    public void deleteBoard(int boardNum, String loginId) {
        BoardEntity board = boardRepository.findById(boardNum)
                .orElseThrow(() -> new IllegalArgumentException("없는 글"));

        // 본인 글만
        if (!loginId.equals(board.getMemberId())) {
            throw new IllegalStateException("삭제 권한 없음");
        }

        // FK 때문에 group 먼저 삭제
        groupRepository.deleteByBoardNum(boardNum);

        // board 삭제
        boardRepository.deleteById(boardNum);
    }
}
