package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="community_group")
public class GroupEntity  {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="group_id")
    private Integer groupId;

    @Column(name="board_num", nullable=false)
    private Integer boardNum;

    @Column(name="member_id", nullable=false, length=20)
    private String memberId;

    @Column(name="role", length=20)
    private String role;      // 기본 MEMBER

    @Column(name="status", length=20)
    private String status;    // 기본 PENDING

    @CreationTimestamp
    @Column(name="joined_date", updatable=false)
    private LocalDateTime joinedDate;
}
