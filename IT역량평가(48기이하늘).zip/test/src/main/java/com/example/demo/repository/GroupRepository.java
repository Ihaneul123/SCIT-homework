package com.example.demo.repository;

import com.example.demo.entity.GroupEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface GroupRepository extends JpaRepository<GroupEntity, Integer> {

    List<GroupEntity> findAllByBoardNumOrderByJoinedDateAsc(Integer boardNum);

    List<GroupEntity> findAllByBoardNumOrderByJoinedDateDesc(Integer boardNum);

    long countByBoardNumAndStatus(Integer boardNum, String status);

    boolean existsByBoardNumAndMemberId(Integer boardNum, String memberId);

    Optional<GroupEntity> findByBoardNumAndMemberId(Integer boardNum, String memberId);

    List<GroupEntity> findAllByMemberIdAndStatusAndRole(String memberId, String status, String role);

    void deleteByBoardNum(Integer boardNum);

}



