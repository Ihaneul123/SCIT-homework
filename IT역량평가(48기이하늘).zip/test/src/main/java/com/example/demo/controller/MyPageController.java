package com.example.demo.controller;

import com.example.demo.dto.MyPageRow;
import com.example.demo.entity.BoardEntity;
import com.example.demo.entity.GroupEntity;
import com.example.demo.repository.BoardRepository;
import com.example.demo.repository.GroupRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequiredArgsConstructor
public class MyPageController {

    private final BoardRepository boardRepository;
    private final GroupRepository groupRepository;

    @GetMapping("/mypage")
    public String mypage(Model model, Principal principal) {

        String loginId = principal.getName();

        // 1) 내 모임(주최)
        List<MyPageRow> myBoards = boardRepository
                .findAllByMemberIdOrderByCreateDateDesc(loginId)
                .stream()
                .map(b -> new MyPageRow(
                        b.getBoardNum(), b.getTitle(), b.getMemberId(),
                        b.getStatus(), b.getHeadcnt(), b.getCapacity()
                ))
                .toList();

        // 2) 참여한 모임(JOINED만 + 리더 제외)
        List<GroupEntity> joined = groupRepository
                .findAllByMemberIdAndStatusAndRole(loginId, "JOINED", "MEMBER");

        List<Integer> joinedBoardNums = joined.stream()
                .map(GroupEntity::getBoardNum)
                .distinct()
                .collect(Collectors.toList());

        List<MyPageRow> joinedBoards = joinedBoardNums.isEmpty()
                ? List.of()
                : boardRepository.findAllByBoardNumInOrderByCreateDateDesc(joinedBoardNums)
                .stream()
                // 혹시 본인 글이 섞일 경우 제거(조건상 참여한 모임은 주최 제외)
                .filter(b -> !loginId.equals(b.getMemberId()))
                .map(b -> new MyPageRow(
                        b.getBoardNum(), b.getTitle(), b.getMemberId(),
                        b.getStatus(), b.getHeadcnt(), b.getCapacity()
                ))
                .toList();

        model.addAttribute("loginId", loginId);
        model.addAttribute("myBoards", myBoards);
        model.addAttribute("joinedBoards", joinedBoards);

        return "member/mypage";
    }
}

