package com.example.demo.dto;

import lombok.*;

@Getter @Setter
@AllArgsConstructor
public class MyPageRow {
    private Integer boardNum;
    private String title;      // 모임명
    private String leaderId;   // 주최자
    private String status;     // OPEN/CLOSED
    private Integer headcnt;   // 현재인원(리더제외)
    private Integer capacity;  // 정원
}
