package com.example.test26;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test26ApplicationTests {

	@Test
	void contextLoads() {
	}

}
