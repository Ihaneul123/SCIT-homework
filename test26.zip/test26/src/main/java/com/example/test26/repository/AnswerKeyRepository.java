package com.example.test26.repository;

import com.example.test26.entity.AnswerKeyEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AnswerKeyRepository extends JpaRepository<AnswerKeyEntity, Integer> {

}

