package com.example.test26.controller;

import com.example.test26.dto.ExamForm;
import com.example.test26.service.ExamService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Slf4j
@Controller
@RequiredArgsConstructor
public class ExamController {

    private final ExamService examService;

    @GetMapping("/exam")
    public String examForm(Model model) {
        model.addAttribute("form", new ExamForm());
        return "exam";
    }

    @PostMapping("/exam")
    public String submit(@ModelAttribute ExamForm form, Model model) {
        try {
            examService.submitAndScore(form);
            return "redirect:/result";
        } catch (IllegalStateException e) {
            if ("DUP_EMAIL".equals(e.getMessage())) {
                model.addAttribute("error", "이미 응시한 이메일입니다.");
                model.addAttribute("form", form);
                return "exam";
            }
            throw e;
        }
    }
}
