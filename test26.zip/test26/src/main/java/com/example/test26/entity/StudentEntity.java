package com.example.test26.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
@EntityListeners(AuditingEntityListener.class)
@Builder
@Data
@Entity
@Table(name="student")
public class StudentEntity {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="studentId")
    private Integer studentId;

    @Column(name="studentName", nullable=false)
    private String studentName;

    @Column(name="studentEmail", nullable=false, unique=true)
    private String studentEmail;

    @Column(name="studentPW", nullable=false)
    private String studentPW;

    @Column(name="testDate", insertable=false, updatable=false)
    private LocalDateTime testDate;

    @Column(name="score")
    private Integer score;

    @Column(name="q1")
    private String q1;
    @Column(name="q2")
    private String q2;
    @Column(name="q3")
    private String q3;
    @Column(name="q4")
    private String q4;
    @Column(name="q5")
    private String q5;
}
