package com.example.test26.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@NoArgsConstructor
@AllArgsConstructor
@EntityListeners(AuditingEntityListener.class)
@Builder
@Data
@Entity
@Table(name = "answerkey")
public class AnswerKeyEntity {

    @Id
    @Column(name = "QNum")
    private Integer qNum;

    @Column(name = "ANum")
    private String aNum;
}
