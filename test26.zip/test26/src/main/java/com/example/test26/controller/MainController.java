package com.example.test26.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    //메인으로 보내기
    @GetMapping("/")
    public String index() {
        return "index";
    }
}
