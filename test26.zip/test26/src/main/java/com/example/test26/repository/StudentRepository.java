package com.example.test26.repository;

import com.example.test26.entity.StudentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.List;

public interface StudentRepository extends JpaRepository<StudentEntity, Integer> {

    Optional<StudentEntity> findByStudentEmail(String studentEmail);

    List<StudentEntity> findAllByOrderByTestDateDesc();

    // 이름 오름차순
    List<StudentEntity> findAllByOrderByStudentNameAsc();

    // 점수 내림차순
    List<StudentEntity> findAllByOrderByScoreDesc();

}
