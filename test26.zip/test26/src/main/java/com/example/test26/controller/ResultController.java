package com.example.test26.controller;
import com.example.test26.entity.StudentEntity;
import com.example.test26.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class ResultController {

    private final StudentRepository studentRepository;

    @GetMapping("/result")
    public String result(
            @RequestParam(required = false) String sort,
            Model model
    ) {
        List<StudentEntity> list;

        if ("name".equals(sort)) {
            list = studentRepository.findAllByOrderByStudentNameAsc();
        } else if ("score".equals(sort)) {
            list = studentRepository.findAllByOrderByScoreDesc();
        } else {
            // 기본: 응시일 내림차순
            list = studentRepository.findAllByOrderByTestDateDesc();
        }

        model.addAttribute("list", list);
        model.addAttribute("sort", sort);
        return "result";
    }
}
