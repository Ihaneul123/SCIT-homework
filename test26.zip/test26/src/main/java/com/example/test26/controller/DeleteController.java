package com.example.test26.controller;

import com.example.test26.entity.StudentEntity;
import com.example.test26.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class DeleteController {

    private final StudentRepository studentRepository;

    // 삭제 확인 화면
    @GetMapping("/delete")
    public String deleteForm(@RequestParam Integer id, Model model) {
        StudentEntity s = studentRepository.findById(id).orElseThrow();
        model.addAttribute("s", s);
        return "delete";
    }

    // 삭제 처리
    @PostMapping("/delete")
    public String delete(@RequestParam Integer id,
                         @RequestParam String studentPW,
                         Model model) {

        StudentEntity s = studentRepository.findById(id).orElseThrow();

        if (!s.getStudentPW().equals(studentPW)) {
            model.addAttribute("s", s);
            model.addAttribute("error", "비밀번호가 일치하지 않습니다.");
            return "delete";
        }

        studentRepository.deleteById(id);
        return "redirect:/result";
    }
}