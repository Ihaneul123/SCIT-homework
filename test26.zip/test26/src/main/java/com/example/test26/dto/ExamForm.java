package com.example.test26.dto;

import lombok.Data;

@Data
public class ExamForm {
    private String studentName;
    private String studentEmail;
    private String studentPW;
    private String q1;
    private String q2;
    private String q3;
    private String q4;
    private String q5;
}
