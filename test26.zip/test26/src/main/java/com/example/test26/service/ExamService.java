package com.example.test26.service;

import com.example.test26.dto.ExamForm;
import com.example.test26.entity.AnswerKeyEntity;
import com.example.test26.entity.StudentEntity;
import com.example.test26.repository.AnswerKeyRepository;
import com.example.test26.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ExamService {

    private final StudentRepository studentRepository;
    private final AnswerKeyRepository answerKeyRepository;

    public int submitAndScore(ExamForm form) {

        // 1️⃣ 이메일 중복 체크
        Optional<StudentEntity> exist =
                studentRepository.findByStudentEmail(form.getStudentEmail());
        if (exist.isPresent()) {
            throw new IllegalStateException("DUP_EMAIL");
        }

        // 2️⃣ 채점
        int score = 0;

        for (int q = 1; q <= 5; q++) {

            AnswerKeyEntity key = answerKeyRepository.findById(q)
                    .orElseThrow(() -> new IllegalStateException("정답 데이터 누락"));

            String correct = normalize(key.getANum());
            String answer;

            switch (q) {
                case 1 -> answer = form.getQ1();
                case 2 -> answer = form.getQ2();
                case 3 -> answer = form.getQ3();
                case 4 -> answer = form.getQ4();
                case 5 -> answer = form.getQ5();
                default -> answer = "";
            }

            if (correct.equals(normalize(answer))) {
                score += 20;
            }
        }

        // 3️⃣ 학생 정보 + 답안 + 점수 저장
        StudentEntity student = StudentEntity.builder()
                .studentName(form.getStudentName())
                .studentEmail(form.getStudentEmail())
                .studentPW(form.getStudentPW())
                .q1(form.getQ1())
                .q2(form.getQ2())
                .q3(form.getQ3())
                .q4(form.getQ4())
                .q5(form.getQ5())
                .score(score)
                .build();

        studentRepository.save(student);

        return score;
    }

    private String normalize(String s) {
        return s == null ? "" : s.trim().toLowerCase();
    }
}
