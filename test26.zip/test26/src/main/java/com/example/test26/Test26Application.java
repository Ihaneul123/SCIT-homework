package com.example.test26;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test26Application {

	public static void main(String[] args) {
		SpringApplication.run(Test26Application.class, args);
	}

}
